process.env.NODE_ENV = process.env.NODE_ENV || 'production';

require('./dist/main.js');

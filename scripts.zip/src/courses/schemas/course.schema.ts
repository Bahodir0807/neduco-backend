import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type CourseDocument = Course & Document;

@Schema({ timestamps: true })
export class Course {
  @Prop({ required: true })
  name: string;

  @Prop()
  description: string;

  @Prop({ type: Types.ObjectId, ref: 'User', required: false })
  teacherId?: Types.ObjectId;

  @Prop({ type: [Types.ObjectId], ref: 'User', default: [] })
  teacherIds!: Types.ObjectId[];

  @Prop({ type: [Types.ObjectId], ref: 'Student', default: [] })
  students?: Types.ObjectId[];

  @Prop({ required: true })
  price: number;
}

export const CourseSchema = SchemaFactory.createForClass(Course);
CourseSchema.index({ teacherIds: 1 });
CourseSchema.index({ students: 1 });
CourseSchema.index({ createdAt: -1 });

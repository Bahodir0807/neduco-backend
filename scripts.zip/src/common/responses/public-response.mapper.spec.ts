import { Role } from '../../roles/roles.enum';
import { UserStatus } from '../../users/user-status.enum';
import {
  mapAdminUser,
  mapPublicResource,
  mapPublicUser,
} from './public-response.mapper';

describe('public response mapper', () => {
  it('normalizes nested users and removes sensitive fields', () => {
    const response = mapPublicResource({
      _id: 'course-1',
      name: 'English',
      password: 'secret',
      hashedPassword: 'hash',
      tokens: ['secret-token'],
      deletedAt: new Date('2026-01-01T00:00:00.000Z'),
      metadata: { internal: true },
      resetToken: 'reset-secret',
      teacherId: {
        _id: 'teacher-1',
        username: 'teacher',
        firstName: 'Ann',
        lastName: 'Lee',
        role: Role.Teacher,
        email: 'teacher@example.com',
        phoneNumber: '+1000000',
        telegramId: '999',
        password: 'hash',
        __v: 0,
      },
      students: [
        {
          _id: 'student-1',
          username: 'student',
          firstName: 'Sam',
          role: Role.Student,
          email: 'student@example.com',
          phoneNumber: '+2000000',
          telegramId: '123',
          refreshToken: 'token',
        },
      ],
    });

    expect(response).toEqual({
      id: 'course-1',
      name: 'English',
      teacherId: {
        id: 'teacher-1',
        fullName: 'Ann Lee',
        role: Role.Teacher,
      },
      students: [
        {
          id: 'student-1',
          fullName: 'Sam',
          role: Role.Student,
        },
      ],
    });
    expect(JSON.stringify(response)).not.toContain('_id');
    expect(JSON.stringify(response)).not.toContain('email');
    expect(JSON.stringify(response)).not.toContain('phoneNumber');
    expect(JSON.stringify(response)).not.toContain('telegramId');
    expect(JSON.stringify(response)).not.toContain('password');
    expect(JSON.stringify(response)).not.toContain('hashedPassword');
    expect(JSON.stringify(response)).not.toContain('refreshToken');
    expect(JSON.stringify(response)).not.toContain('tokens');
    expect(JSON.stringify(response)).not.toContain('deletedAt');
    expect(JSON.stringify(response)).not.toContain('metadata');
    expect(JSON.stringify(response)).not.toContain('resetToken');
  });

  it('maps top-level admin users with contact fields and without student profile fields', () => {
    const response = mapAdminUser({
      _id: 'user-1',
      username: 'admin',
      firstName: 'A',
      lastName: 'User',
      role: Role.Admin,
      status: UserStatus.Active,
      isActive: true,
      branchIds: ['branch-1'],
      email: 'admin@example.com',
      phoneNumber: '+3000000',
      password: 'hash',
      tokenHash: 'hash',
    });

    expect(response).toMatchObject({
      id: 'user-1',
      username: 'admin',
      fullName: 'A User',
      role: Role.Admin,
      status: UserStatus.Active,
      isActive: true,
      branchIds: ['branch-1'],
      email: 'admin@example.com',
      phoneNumber: '+3000000',
    });
    expect(response).not.toHaveProperty('_id');
    expect(response).not.toHaveProperty('password');
    expect(response).not.toHaveProperty('tokenHash');
    expect(response).not.toHaveProperty('studentYear');
    expect(response).not.toHaveProperty('paymentMethod');
    expect(response).not.toHaveProperty('contactOwner');
    expect(response).not.toHaveProperty('contactOwnerFullName');
    expect(response).not.toHaveProperty('contactOwnerRelation');
  });

  it('keeps nested user shape compact and consistent', () => {
    expect(
      mapPublicUser({
        _id: 'student-1',
        username: 'fallback-name',
        role: Role.Student,
        branchIds: ['branch-1'],
      }),
    ).toEqual({
      id: 'student-1',
      fullName: 'fallback-name',
      role: Role.Student,
    });
  });

  it('drops raw user reference ids when relationships are not populated', () => {
    const response = mapPublicResource({
      _id: 'schedule-1',
      course: {
        _id: 'course-1',
        name: 'Math',
        teacherId: 'teacher-1',
        students: ['student-1', 'student-2'],
      },
      group: {
        _id: 'group-1',
        name: 'A1',
        teacher: 'teacher-1',
        students: ['student-1', 'student-2'],
      },
      teacher: 'teacher-1',
      students: ['student-1'],
    });

    expect(response).toEqual({
      id: 'schedule-1',
      course: {
        id: 'course-1',
        name: 'Math',
        students: [],
      },
      group: {
        id: 'group-1',
        name: 'A1',
        students: [],
      },
      students: [],
    });
    expect(JSON.stringify(response)).not.toContain('teacher-1');
    expect(JSON.stringify(response)).not.toContain('student-1');
    expect(JSON.stringify(response)).not.toContain('student-2');
  });
});
